<?php
/**
 * Silence is golden.
 *
 * @package BackupBuddy
 */
