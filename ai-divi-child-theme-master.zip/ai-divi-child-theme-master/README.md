# AI-divi-child

Please replace child theme name and directory name depends on what website you are using this. Thanks!

----------
11-23-2016
----------

- Remove duplicate style.css (base on Jona's Report)
- Add inherit font class (.inherit-font) we can add this to control font of h2, h3, h4, h5 in text module
- Allow user to upload SVG file


----------
12-06-2016
----------

- Remove BackUPWordpress
- Add Backup buddy

----------
05-30-2019
----------

- Add [site_year] shortcode, dynamically get's the year
- Update the header and footer to Divi's Version: 3.23.3 files
- Add Font Awesome 4.7 and 5 on Theme Customizer
- Add /assets/ folder for the custom scripts
- Add /includes/ folder with array helper for custom shortcodes

----------
06-06-2019
----------

- Add social icons in Theme options setting
- Add /includes/social_icons.php folder to add more social icons
- Add /panel_options.php file to display icons in Divi Theme options
- Update function.php file to load the icons options dynamically 
